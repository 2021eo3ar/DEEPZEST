Age = int(input("Enter Your age Please: "))
if Age<3:
    print("Your Ticket is Free")
elif Age>=3 and Age<=12:
    print("Your ticket price is 15 Inr")
else:
    print("your ticket price is 20 Inr")